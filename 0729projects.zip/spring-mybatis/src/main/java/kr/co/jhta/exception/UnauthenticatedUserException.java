package kr.co.jhta.exception;

public class UnauthenticatedUserException extends HTAException {

	public UnauthenticatedUserException(String message) {
		super(message);
	}
}
