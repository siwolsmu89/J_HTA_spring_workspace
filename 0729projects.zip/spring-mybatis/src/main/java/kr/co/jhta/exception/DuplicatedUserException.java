package kr.co.jhta.exception;

public class DuplicatedUserException extends HTAException {

	public DuplicatedUserException(String message) {
		super(message);
	}
}
