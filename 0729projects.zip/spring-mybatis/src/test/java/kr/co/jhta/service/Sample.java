package kr.co.jhta.service;

public class Sample {

	public int plus(int x, int y) {
		int result = x + y;
		return result;
	}
	
	public int minus(int x, int y) {
		int result = x - y;
		return result;
	}
}
