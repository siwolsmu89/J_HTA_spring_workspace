package kr.co.jhta.di.step1;

public interface NotificationService {
	
	void notice(String dept, String subject, String content);
}
