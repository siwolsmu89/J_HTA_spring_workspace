package kr.co.jhta.di.step2;

public interface AlarmService {
	
	void alarm(String message);
}
