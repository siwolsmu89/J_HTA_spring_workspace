package kr.co.jhta.di.service.step7;

import java.util.List;

import kr.co.jhta.di.vo.User;

public interface UserService {
	List<User> getAllUser();
}
