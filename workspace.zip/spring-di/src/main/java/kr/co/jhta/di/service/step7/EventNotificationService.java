package kr.co.jhta.di.service.step7;

public interface EventNotificationService {
	
	void noticeEvent(String eventName, String eventContent);
}
