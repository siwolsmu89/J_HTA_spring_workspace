package kr.co.jhta.di.service;

public interface Output {
	
	void write(String text);
}
