package kr.co.jhta.di.service.step1;

public class Main {

	public static void main(String[] args) {
		Reporter reporter = new Reporter();
		reporter.report("프로젝트 회의", "파이널 프로젝트는 x일 ~ x일까지 진행하기로 하였습니다.");
	}
}
