package kr.co.jhta.di.service.step8;


public interface NoticeService {
	public void notice(String dept, String subject, String content);
}
