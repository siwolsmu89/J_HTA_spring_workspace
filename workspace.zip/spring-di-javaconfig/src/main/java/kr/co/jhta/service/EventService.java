package kr.co.jhta.service;

public interface EventService {

	void notice(String dept, String subject, String content);
}
